export const COINGECKO_API_URL = 'https://api.coingecko.com/api/v3';
export const PER_PAGE = 100;
export const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes